typedef struct _phoneData
{
	char name[20];
	char phoneNum[20];
}PHONEDATA;