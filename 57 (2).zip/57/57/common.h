#include <stdio.h>
#include <string.h>
#pragma warning(disable:4996)